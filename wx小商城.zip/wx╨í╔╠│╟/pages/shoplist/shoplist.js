// pages/shoplist/shoplist.js
Page({

  /**
   * 页面的初始数据  
   */
  data: {
 list:[],  //商品列表
 pageIndex:0, //商品分页页码
 pageSize:5,  //页大小
 hasMore:true  //是否还有更多数据
  },

loadMore:function(){
  //加载更多数据
  //1.发送ajax请求
  if(this.data.hasMore==false)return;
  wx.request({
    url: 'http://127.0.0.1:3000/newslist',
    data:{pno:++this.data.pageIndex,pageSize:this.data.pageSize},
    success:(result)=>{
      //总页数
    var pageCount=result.data.pageCount;
    //当前页数
    var pno=this.data.pageIndex;
    //当前页内容
    var data=result.data.data;
    //是否还有下一页判断条件
    var flag=pno < pageCount;
    var list=this.data.list.concat(result.data.data)
    this.setData({
      list:list,
      hasMore:flag,
      pageIndex: pno
    })
    }
  })
  //2.获取返回数据
  //3.保存list列表
  wx.showLoading({
    title: '正在加载',
  });
  setTimeout(function(){
    wx.hideLoading();
  },1000);
},


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  this.loadMore();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
 this.loadMore();
 console.log(111);
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})