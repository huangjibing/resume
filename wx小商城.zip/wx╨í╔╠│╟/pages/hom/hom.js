// pages/wxXZ/wxXZ.js
Page({

  /**
   * 页面的初始数据
   */
  handleJumpNews:function(event){
    var id=event.target.dataset.id;
    if(id==1)
    wx.navigateTo({
      url: '/pages/news/news',
    })
  
  },
getImagelist:function () {
    wx.request({
      url: 'http://127.0.0.1:3000/imagelist',
      success: (res) => {
        this.setData({
          list:res.data
        })
        
      }
    })
  },
  data: {
    img: [{ id: 1, img_url: "http://127.0.0.1:3000/img/grid-01.png",name:"美食" },
      { id: 2, img_url: "http://127.0.0.1:3000/img/grid-02.png", name: "洗浴" },
      { id: 3, img_url: "http://127.0.0.1:3000/img/grid-03.png", name: "结婚" },
      { id: 4, img_url: "http://127.0.0.1:3000/img/grid-04.png", name: "卡拉OK" },
      { id: 5, img_url: "http://127.0.0.1:3000/img/grid-05.png", name: "打包" },
      { id: 6, img_url: "http://127.0.0.1:3000/img/grid-06.png", name: "学习" },
      { id: 7, img_url: "http://127.0.0.1:3000/img/grid-07.png", name: "汽车保养" },
      { id: 8, img_url: "http://127.0.0.1:3000/img/grid-09.png", name: "打扫" },
      { id: 9, img_url: "http://127.0.0.1:3000/img/grid-08.png", name: "更多" }
      ],

      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   this.getImagelist();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})