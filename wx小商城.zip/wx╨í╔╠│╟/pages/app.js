//app.js
//1:加载模块
const express = require("express");
const pool  = require("./pool");
//2:创建express对象
var app = express();
//服务器node.js 允许跨域访问配置项
//2.1:引入跨域模块   
const cors = require("cors");
//2.2:配置允许哪个程序跨域访问 脚手架   11:16
app.use(cors({
  origin:[
    "http://127.0.0.1:3001","http://localhost:3001"],
  credentials:true
}))

//3:指定静态目录
//服务器指定目录 绝对路径 出错
app.use(express.static(__dirname+"/public"));

//4:绑定监听端口
app.listen(3000);
//功能一:学子商城首页图片轮播
//GET /imagelist   json
app.get("/imagelist",(req,res)=>{
  var obj = [
 {id:1,img_url:"http://127.0.0.1:3000/img/shop1.png"},
 {id:2,img_url:"http://127.0.0.1:3000/img/shop2.png"},
 {id:3,img_url:"http://127.0.0.1:3000/img/shop3.png"},
 {id:4,img_url:"http://127.0.0.1:3000/img/shop4.png"},
];
  res.send(obj)
});
  
//支付页面
app.get("/phop",(req,res)=>{
var obj=[{id:1,img_url:"http://127.0.0.1:3000/img/shop1.png"}]

res.send(obj)
})

   //wx
	app.get("/test01",(req,res)=>{
	var id=req.query.id;
	var age=req.query.age;
	res.send(id+1+age);
	})
    //wx轮播图
	app.get("/test02",(req,res)=>{
	var obj=[{id:1,img_url:"http://127.0.0.1:3000/img/banner1.png"},
		{id:2,img_url:"http://127.0.0.1:3000/img/banner2.png"},
		{id:3,img_url:"http://127.0.0.1:3000/img/banner3.png"},]
		res.send(obj);
	})

	app.get("/newslist1",(req,res)=>{
	var obj=[{id:1,ctime:"2018-9-10",title:"手机盛典",img_url:"http://127.0.0.1:3000/img/banner1.png",desc:"手机中的战斗机"},
		{id:2,ctime:"2018-9-11",title:"手机盛典",img_url:"http://127.0.0.1:3000/img/banner2.png",desc:"手机中的战斗机"},
		{id:3,ctime:"2018-9-12",title:"手机盛典",img_url:"http://127.0.0.1:3000/img/banner3.png",desc:"手机中的战斗机"},]
		res.send(obj);
	})
//wx  node.js
	app.post("/postProduct",(req,res)=>{
	req.on("data",(buff)=>{
	var obj=qs.parse(buff.toString());
	var pno=obj.pno;
	var price=obj.price;
	res.send({code:1,msg:":"+pno+":"+price});
	});
	});